import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"; // Importa los componentes necesarios
import "./css/styles.css";
import HomePage from "./views/HomePage";
import CartPage from "./views/CartPage";
import UsersPage from "./views/UsersPage";
const App = () => {
  return (
    <Router>
      {/* Rutas */}
      <Routes>
        <Route path="/usuarios" element={<UsersPage />} />
        <Route path="/" element={<HomePage />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
    </Router>
  );
};

export default App;