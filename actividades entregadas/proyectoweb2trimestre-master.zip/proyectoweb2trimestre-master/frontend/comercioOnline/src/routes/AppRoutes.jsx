// import React from "react";
// import { Routes, Route } from "react-router-dom";
// import UsersPage from "../views/UsersPage";
// import HomePage from "../views/HomePage";
// import CartPage from "../views/CartPage";

// const AppRoutes = () => {
//   return (
//     <Routes>
//       <Route path="/usuarios" element={<UsersPage />} />
//       {/* Agrega más rutas según sea necesario */}
//       <Route path="/home" element={<HomePage />} />
//       <Route path="/cart" element={<CartPage />} />
//     </Routes>
//   );
// };

// export default AppRoutes;