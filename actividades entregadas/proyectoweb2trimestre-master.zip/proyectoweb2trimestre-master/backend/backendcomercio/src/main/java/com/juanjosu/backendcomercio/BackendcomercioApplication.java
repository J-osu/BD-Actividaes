package com.juanjosu.backendcomercio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendcomercioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendcomercioApplication.class, args);
	}

}
