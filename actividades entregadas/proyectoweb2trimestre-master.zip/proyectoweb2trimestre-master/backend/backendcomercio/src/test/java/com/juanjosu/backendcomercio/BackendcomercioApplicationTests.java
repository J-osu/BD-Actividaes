package com.juanjosu.backendcomercio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcomercioApplicationTests {

	@Test
	void contextLoads() {
	}

}
